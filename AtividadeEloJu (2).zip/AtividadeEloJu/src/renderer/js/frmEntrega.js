let modoEdicao = false;
let idEmEdicao = null;

window.api.aoReceberEntregaParaEditar((entrega) => {
  document.querySelector("#destinatario").value = entrega.destinatario;
  document.querySelector("#destinatario").value = entrega.destinatario;
  document.querySelector("#produto").value = entrega.produto;
  document.querySelector("#quantidade").value = entrega.quantidade;
  document.querySelector("#cep").value = entrega.cep;
  document.querySelector("#endereco").value = entrega.endereco;
  document.querySelector("#data_entrega").value = entrega.data_entrega;

   const d = new Date(entrega.data_entrega);
    document.querySelector('#data_entrega').value = d.toISOString().slice(0, 10);

    modoEdicao = true;
    idEmEdicao = entrega.id;
});


document.querySelector("#formEntrega").addEventListener("submit", async (e) => {
    e.preventDefault(); // Evita o piscar da tela

    const dados = Object.fromEntries(new FormData(e.target));
    if (modoEdicao) {
      await window.api.atualizarEntrega({ id: idEmEdicao, ...dados });
    } else {
      try {
        const resultado = await window.api.criarEntrega(dados);
        console.log("Entrega cadastrada:", resultado);
      } catch (erro) {
        console.error("Deu ruim ao cadastrar a entrega:", erro);
      }
    }

    window.close(); // fecha o modal; frmPrincipal recarrega quando o foco voltar

    
    console.log("Entrega a cadastrar:", dados);
});
