let entregasCarregados = [];
let idParaExcluirEntrega = null;


const carregarEntregas = async () => {
  entregasCarregados = await window.api.listarEntregas();

  const linhas = entregasCarregados
    .map(
      (entrega) => `
      <tr>
      <td>${entrega.destinatario}</td>
      <td>${entrega.produto}</td>
      <td>${entrega.quantidade}</td>
      <td>${entrega.cep}</td>
      <td>${entrega.endereco}</td>
      <td>${new Date(entrega.data_entrega).toLocaleDateString('pt-BR')}</td>
      <td>
        <button class="btn btn-sm btn-primary" onclick="editarEntrega(${entrega.id})">
          Editar
        </button>
        <button class="btn btn-sm btn-danger" onclick="abrirConfirmacaoExclusaoEntrega(${entrega.id})">
          Excluir
        </button>
        </td>
    </tr>`,
    )
    .join("");

  document.querySelector("#tbodyEntregas").innerHTML = linhas;
};

const editarEntrega = (id) => {
  const entrega = entregasCarregados.find((e) => e.id === id);
  window.api.editarEntrega(entrega);
};

const abrirConfirmacaoExclusaoEntrega = (id) => {
  const entrega = entregasCarregados.find((item) => item.id === id);

  document.querySelector("#nomeEntregaExcluir").textContent = entrega.destinatario;
  idParaExcluirEntrega = id;

  const modal = new bootstrap.Modal(
    document.querySelector("#modalConfirmarExclusaoEntrega"),
  );
  modal.show();
};

document
  .querySelector("#btnConfirmarExclusaoEntrega")
  .addEventListener("click", async () => {
    await window.api.excluirEntrega(idParaExcluirEntrega);

    const modal = bootstrap.Modal.getInstance(
      document.querySelector("#modalConfirmarExclusaoEntrega"),
    );
    modal.hide();

    carregarEntregas();
  });

carregarEntregas();

window.addEventListener("focus", () => {
  carregarEntregas();
});
